SOUNDTawn WEBSITE — FREE HOSTING

This folder contains the ready-to-publish SoundTawn website.

Files:
- index.html — website
- soundtawn.jpg — optimized artist photo

The website is designed for free static hosting such as GitHub Pages.

IMPORTANT:
Before publishing, replace YOUR-USERNAME in the JSON-LD inside index.html with your GitHub username once you know it. This improves the site's structured information.

No passwords, payment details, or private information are included.
